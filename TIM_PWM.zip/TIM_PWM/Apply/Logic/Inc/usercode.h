#ifndef	__USERCODE_H_
#define	__USERCODE_H_

void UserLogic_Code(void);

#endif
