#ifndef __DRV_DELAY_H_
#define __DRV_DELAY_H_

#include "drv_hal.h"

void Drv_Delay_Ms(uint32_t _ulVal);
void Drv_Delay_Us(uint32_t _ulVal);

#endif
