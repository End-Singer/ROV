#include "stm32f10x.h"                  // Device header
#include "Delay.h" 

// �򻯰������ƽṹ
typedef struct {
    uint16_t currentCCR;     // ��ǰCCRֵ
    uint16_t targetCCR;      // Ŀ��CCRֵ
    uint16_t finalTargetCCR; // ����Ŀ��CCR�����ڷ���ת��
    uint8_t state;           // 0=ֹͣ, 1=�仯��, 2=��Ҫ�ڶ��׶�
    uint32_t lastUpdateTime; // �ϴθ���ʱ��
} SimpleMotorCtrl_t;

// ȫ�ֵ����������
static SimpleMotorCtrl_t motorCtrl[4] = {
    {1500, 1500, 1500, 0, 0},  // ���1
    {1500, 1500, 1500, 0, 0},  // ���2
    {1500, 1500, 1500, 0, 0},  // ���3
    {1500, 1500, 1500, 0, 0}   // ���4
};

// ��ʼ���������ֲ���
void PWM_Init(void)
{
    // 1. ʱ��ʹ��
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4 | RCC_APB1Periph_TIM3, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    // 2. GPIO����
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // 3. ��ʱ��TIM4ʱ������
    TIM_InternalClockConfig(TIM4);
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
    
    // 4. ��ʱ��TIM3ʱ������
    TIM_InternalClockConfig(TIM3);
    TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
    
    // 5. PWM�������
    TIM_OCInitTypeDef TIM_OCInit_Structure;
    TIM_OCInit_Structure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInit_Structure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInit_Structure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInit_Structure.TIM_Pulse = 1500;
    
    // TIM4�ĸ�ͨ��
    TIM_OC1Init(TIM4, &TIM_OCInit_Structure);
    TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC2Init(TIM4, &TIM_OCInit_Structure);
    TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC3Init(TIM4, &TIM_OCInit_Structure);
    TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC4Init(TIM4, &TIM_OCInit_Structure);
    TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
    
    // TIM3ͨ��3
    TIM_OCInit_Structure.TIM_Pulse = 0;
    TIM_OC3Init(TIM3, &TIM_OCInit_Structure);
    TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);
    
    // 6. ʹ��ARRԤװ��
    TIM_ARRPreloadConfig(TIM4, ENABLE);
    TIM_ARRPreloadConfig(TIM3, ENABLE);
    
    // 7. ������ʱ��
    TIM_Cmd(TIM4, ENABLE);
    TIM_Cmd(TIM3, ENABLE);
}

// ������Ʊ��ֲ���
void PWM_SetServo(uint16_t Compare)
{
    TIM_SetCompare3(TIM3, Compare);
}

/**
  * @brief  ���µ��������PWM������򻯰棩
  * @param  index: ���������0-3��
  * @retval ��
  */
static void UpdateMotorPWM(uint8_t index)
{
    SimpleMotorCtrl_t* mc = &motorCtrl[index];
    
    if (mc->state == 0) return; // ����Ҫ����
    
    uint32_t currentTime = SysTick->VAL;
    uint32_t elapsed = (currentTime > mc->lastUpdateTime) ? 
                      (currentTime - mc->lastUpdateTime) : 
                      (0xFFFFFFFF - mc->lastUpdateTime + currentTime);
    
    // ÿ1ms����һ�Σ��ɵ�����
    if (elapsed < 72000) return; // 72MHz/1000 = 72000 ticks/ms
    
    // ִ�и���
    if (mc->currentCCR < mc->targetCCR) {
        mc->currentCCR++;
    } else if (mc->currentCCR > mc->targetCCR) {
        mc->currentCCR--;
    }
    
    // ����PWM���
    switch(index) {
        case 0: TIM_SetCompare1(TIM4, mc->currentCCR); break;
        case 1: TIM_SetCompare2(TIM4, mc->currentCCR); break;
        case 2: TIM_SetCompare3(TIM4, mc->currentCCR); break;
        case 3: TIM_SetCompare4(TIM4, mc->currentCCR); break;
    }
    
    mc->lastUpdateTime = currentTime;
    
    // ����Ƿ񵽴�Ŀ��
    if (mc->currentCCR == mc->targetCCR) {
        if (mc->state == 2) {
            // ��ʼ�ڶ��׶Σ���ֹͣ������Ŀ��
            mc->targetCCR = mc->finalTargetCCR;
            mc->state = 1;
        } else {
            mc->state = 0; // ���
        }
    }
}

/**
  * @brief  �������е����PWM�������ѭ�����ã�
  * @retval ��
  */
void PWM_UpdateAll(void)
{
    for (uint8_t i = 0; i < 4; i++) {
        UpdateMotorPWM(i);
    }
}

/**
  * @brief  �ƽ���1��PB6/TIM4_CH1���ٶȿ���
  * @param  direction: 1=��ת, -1=��ת, 0=ֹͣ
  * @retval ��
  */
void Motor1_SetSpeed(int8_t direction)
{
    SimpleMotorCtrl_t* mc = &motorCtrl[0];
    uint16_t target;
    
    // ȷ��Ŀ��ֵ
    if (direction == 1) {
        target = 2000;
    } else if (direction == -1) {
        target = 1000;
    } else {
        target = 1500;
    }
    
    // ����Ѿ���Ŀ��ֵ��ֱ�ӷ���
    if (mc->currentCCR == target && mc->state == 0) {
        return;
    }
    
    // ����Ƿ���Ҫ����ת
    if (direction != 0 && 
        ((mc->currentCCR > 1500 && target < 1500) || 
         (mc->currentCCR < 1500 && target > 1500))) {
        // ��Ҫ��ת���ȵ�1500
        mc->targetCCR = 1500;
        mc->finalTargetCCR = target; // ��ס����Ŀ��
        mc->state = 2; // �����Ҫ�ڶ��׶�
    } else {
        // ֱ�ӱ仯
        mc->targetCCR = target;
        mc->finalTargetCCR = target;
        mc->state = 1;
    }
}

/**
  * @brief  �ƽ���2��PB7/TIM4_CH2���ٶȿ���
  * @param  direction: 1=��ת, -1=��ת, 0=ֹͣ
  * @retval ��
  */
void Motor2_SetSpeed(int8_t direction)
{
    SimpleMotorCtrl_t* mc = &motorCtrl[1];
    uint16_t target;
    
    if (direction == 1) target = 2000;
    else if (direction == -1) target = 1000;
    else target = 1500;
    
    if (mc->currentCCR == target && mc->state == 0) return;
    
    if (direction != 0 && 
        ((mc->currentCCR > 1500 && target < 1500) || 
         (mc->currentCCR < 1500 && target > 1500))) {
        mc->targetCCR = 1500;
        mc->finalTargetCCR = target;
        mc->state = 2;
    } else {
        mc->targetCCR = target;
        mc->finalTargetCCR = target;
        mc->state = 1;
    }
}

/**
  * @brief  �ƽ���3��PB8/TIM4_CH3���ٶȿ���
  * @param  direction: 1=��ת, -1=��ת, 0=ֹͣ
  * @retval ��
  */
void Motor3_SetSpeed(int8_t direction)
{
    SimpleMotorCtrl_t* mc = &motorCtrl[2];
    uint16_t target;
    
    if (direction == 1) target = 2000;
    else if (direction == -1) target = 1000;
    else target = 1500;
    
    if (mc->currentCCR == target && mc->state == 0) return;
    
    if (direction != 0 && 
        ((mc->currentCCR > 1500 && target < 1500) || 
         (mc->currentCCR < 1500 && target > 1500))) {
        mc->targetCCR = 1500;
        mc->finalTargetCCR = target;
        mc->state = 2;
    } else {
        mc->targetCCR = target;
        mc->finalTargetCCR = target;
        mc->state = 1;
    }
}

/**
  * @brief  �ƽ���4��PB9/TIM4_CH4���ٶȿ���
  * @param  direction: 1=��ת, -1=��ת, 0=ֹͣ
  * @retval ��
  */
void Motor4_SetSpeed(int8_t direction)
{
    SimpleMotorCtrl_t* mc = &motorCtrl[3];
    uint16_t target;
    
    if (direction == 1) target = 2000;
    else if (direction == -1) target = 1000;
    else target = 1500;
    
    if (mc->currentCCR == target && mc->state == 0) return;
    
    if (direction != 0 && 
        ((mc->currentCCR > 1500 && target < 1500) || 
         (mc->currentCCR < 1500 && target > 1500))) {
        mc->targetCCR = 1500;
        mc->finalTargetCCR = target;
        mc->state = 2;
    } else {
        mc->targetCCR = target;
        mc->finalTargetCCR = target;
        mc->state = 1;
    }
}
