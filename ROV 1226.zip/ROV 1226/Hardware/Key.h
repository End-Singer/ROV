#ifndef __Key_H
#define __Key_H

void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
